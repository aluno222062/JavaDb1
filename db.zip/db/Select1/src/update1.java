import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class update1 {
	private static final String HOST = "jdbc:mysql://localhost/vendasdb?autoReconnect=true&useSSL=false";
	private static final String USER = "root";
	private static final String PASS = "";

	public update1() {
		// TODO Auto-generated constructor stub
		createVendedor();
	}
	
	private Connection connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Connecting to a selected database...");
			Connection conn = DriverManager.getConnection(HOST, USER, PASS);
			return conn;

		} catch (ClassNotFoundException ex1) {
			return null;
		} catch (SQLException ex2) {
			return null;
		}
	}
	
	
	private void createVendedor() {
		Connection conn = connect();
		
		if(conn == null) {
			System.out.println("Erro na conexao à base de dados");
			return;
		}
		

		
		String sql = "update vendedores set nome = 'Ronaldo', ";
		sql += "morada  = 'Ericeira', telefone = '984345231' where id = 17";
		
		try {
			Statement st = conn.createStatement();
			st.executeUpdate(sql);
			System.out.println("Venndedor 17 atualizado");
			conn.close();
		}catch(SQLException ex) {
			System.out.println("Erro na atualizacao do vendedor");
			System.out.println(sql);
			
		}

	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new insert1();
	}

}

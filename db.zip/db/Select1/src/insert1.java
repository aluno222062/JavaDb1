import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class insert1 {
	private static final String HOST = "jdbc:mysql://localhost/vendasdb?autoReconnect=true&useSSL=false";
	private static final String USER = "root";
	private static final String PASS = "";

	public insert1() {
		// TODO Auto-generated constructor stub
		createVendedor();
	}
	
	private Connection connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Connecting to a selected database...");
			Connection conn = DriverManager.getConnection(HOST, USER, PASS);
			return conn;

		} catch (ClassNotFoundException ex1) {
			return null;
		} catch (SQLException ex2) {
			return null;
		}
	}
	
	
	private void createVendedor() {
		Connection conn = connect();
		
		if(conn == null) {
			System.out.println("Erro na conexao à base de dados");
			return;
		}
		

		
		String sql = "insert into vendedores (distritoId, nome, morada, telefone) values(1, ";
		sql += "11, 'Roberto', 'Caxias')";
		
		try {
			Statement st = conn.createStatement();
			st.executeUpdate(sql);
			System.out.println("Vendedor Criado");
			conn.close();
		}catch(SQLException ex) {
			System.out.println("Erro na criaçao do vendedor");
			System.out.println(sql);
			
		}

	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new insert1();
	}

}

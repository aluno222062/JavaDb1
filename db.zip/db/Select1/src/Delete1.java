import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Delete1 {
	private static final String HOST = "jdbc:mysql://localhost/vendasdb?autoReconnect=true&useSSL=false";
	private static final String USER = "root";
	private static final String PASS = "";

	public Delete1() {
		// TODO Auto-generated constructor stub
		deleteVendedor();
	}
	
	private Connection connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Connecting to a selected database...");
			Connection conn = DriverManager.getConnection(HOST, USER, PASS);
			return conn;

		} catch (ClassNotFoundException ex1) {
			return null;
		} catch (SQLException ex2) {
			return null;
		}
	}
	
	
	private void deleteVendedor() {
		Connection conn = connect();
		
		if(conn == null) {
			System.out.println("Erro na conexao à base de dados");
			return;
		}
		

		
		String sql = "delete from vendedores where id = 17";
		
		try {
			Statement st = conn.createStatement();
			st.executeUpdate(sql);
			System.out.println("Vendedor Deletado");
			conn.close();
		}catch(SQLException ex) {
			System.out.println("Erro a deletar");
			System.out.println(sql);
			
		}

	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new insert1();
	}

}

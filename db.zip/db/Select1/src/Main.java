import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Main {
	private static final String HOST = "jdbc:mysql://localhost/vendasdb?autoReconnect=true&useSSL=false";
	private static final String USER = "root";
	private static final String PASS = "";

	public Main() {
		// TODO Auto-generated constructor stub
		getVendedores();
	}

	private Connection connect() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("Connecting to a selected database...");
			Connection conn = DriverManager.getConnection(HOST, USER, PASS);
			return conn;

		} catch (ClassNotFoundException ex1) {
			return null;
		} catch (SQLException ex2) {
			return null;
		}
	}

	private void getVendedores() {
		Connection conn = connect();

		if (conn == null) {
			System.out.println("Erro na conexão à base de dados");
			return;
		}

		// ler registos da base de dados
		String sql = "";
		try {
			Statement st = conn.createStatement();
			sql = "select * from vendedores";
			ResultSet rs = st.executeQuery(sql);

			// Percorrer os registos no resultset:
			while (rs.next()) {
				int id = rs.getInt("id");
				int distritoId = rs.getInt("distritoId");
				String nome = rs.getString("nome");
				String morada = rs.getString("morada");
				String telefone = rs.getString("telefone");

				System.out.println(id + " " + nome + " " + morada + " " + telefone);
			}

			System.out.println("=============================");

			rs.beforeFirst();
			while (rs.next()) {
				int id = rs.getInt(1);
				int distritoId = rs.getInt(2);
				String nome = rs.getString(3);
				String morada = rs.getString(4);
				String telefone = rs.getString(5);

				System.out.println(id + " " + nome + " " + morada + " " + telefone);
			}
			conn.close();
		} catch (SQLException ex) {
			// TODO Auto-generated catch block
			System.out.println("Erro na pesquisa de vendedores");
			System.out.println(sql);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}

import java.sql.DriverManager;
import java.sql.SQLException;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class Main {
	private static final String HOST = "jdbc:mysql://@localhost/vendasdb?serverTimezone=UTC";
	private static final String USER = "root";
	private static final String PASS = "";
	
	java.sql.Connection conn = null;
	Statement stmt = null;
	
	
	public Main() {
		// TODO Auto-generated constructor stub
		connectDb();
	}
	
	private void connectDb() {
		
		try {
			//STEP 1: Register JDBC driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//STEP 2: Open a Connection
			System.out.println("Connecting to a selected database...");
			conn = DriverManager.getConnection(HOST, USER, PASS);
			System.out.println("Connected database successfully...");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			
		} catch (SQLException e2) {
			System.out.println("Erro na conexao a base de dados");
		} finally {
			if(conn != null) {
				try {
					conn.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();

	}

}
